import React, { useState } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import AccountsView from './components/AccountsView';
import AccountDetails from './components/AccountDetails';

interface Account {
  id: number;
  name: string;
  industry: string;
  website: string;
  owner: string;
  created: string;
  revenue: string;
  status: string;
  phone: string;
  email: string;
}

const mockAccounts: Account[] = [
  {
    id: 1,
    name: 'Acme Corporation',
    industry: 'Manufacturing',
    website: 'acme.com',
    owner: 'Vishal Paswan',
    created: '3/7/2025',
    revenue: '$2.5M',
    status: 'Active',
    phone: '+1 (555) 123-4567',
    email: 'contact@acme.com'
  },
  {
    id: 2,
    name: 'TechFlow Solutions',
    industry: 'Technology',
    website: 'techflow.com',
    owner: 'Sarah Johnson',
    created: '3 days ago',
    revenue: '$1.8M',
    status: 'Active',
    phone: '+1 (555) 234-5678',
    email: 'hello@techflow.com'
  },
  {
    id: 3,
    name: 'Amazon',
    industry: 'E-commerce',
    website: 'amazon.com',
    owner: 'Vishal Paswan',
    created: '07/06/2025, 06:42',
    revenue: '$15.2B',
    status: 'Active',
    phone: '+1 (206) 266-1000',
    email: 'business@amazon.com'
  },
  {
    id: 4,
    name: 'Microsoft Corporation',
    industry: 'Technology',
    website: 'microsoft.com',
    owner: 'John Smith',
    created: '2/28/2025',
    revenue: '$8.9B',
    status: 'Active',
    phone: '+1 (425) 882-8080',
    email: 'sales@microsoft.com'
  },
  {
    id: 5,
    name: 'Tesla Inc',
    industry: 'Automotive',
    website: 'tesla.com',
    owner: 'Emma Davis',
    created: '3/1/2025',
    revenue: '$3.2B',
    status: 'Prospect',
    phone: '+1 (650) 681-5000',
    email: 'business@tesla.com'
  },
  {
    id: 6,
    name: 'Google LLC',
    industry: 'Technology',
    website: 'google.com',
    owner: 'Michael Brown',
    created: '2/15/2025',
    revenue: '$12.1B',
    status: 'Active',
    phone: '+1 (650) 253-0000',
    email: 'enterprise@google.com'
  },
  {
    id: 7,
    name: 'Apple Inc',
    industry: 'Technology',
    website: 'apple.com',
    owner: 'Lisa Wang',
    created: '2/20/2025',
    revenue: '$18.5B',
    status: 'Active',
    phone: '+1 (408) 996-1010',
    email: 'business@apple.com'
  },
  {
    id: 8,
    name: 'Netflix Inc',
    industry: 'Entertainment',
    website: 'netflix.com',
    owner: 'David Chen',
    created: '2/25/2025',
    revenue: '$890M',
    status: 'Prospect',
    phone: '+1 (408) 540-3700',
    email: 'partnerships@netflix.com'
  }
];

function App() {
  const [activeTab, setActiveTab] = useState('accounts');
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredAccounts, setFilteredAccounts] = useState(mockAccounts);
  const [selectedAccountId, setSelectedAccountId] = useState<number | null>(null);

  const handleSearch = (value: string) => {
    setSearchTerm(value);
    const filtered = mockAccounts.filter(account =>
      account.name.toLowerCase().includes(value.toLowerCase()) ||
      account.industry.toLowerCase().includes(value.toLowerCase()) ||
      account.owner.toLowerCase().includes(value.toLowerCase())
    );
    setFilteredAccounts(filtered);
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setSelectedAccountId(null);
  };

  const handleAccountSelect = (accountId: number) => {
    setSelectedAccountId(accountId);
  };

  const handleBackToAccounts = () => {
    setSelectedAccountId(null);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar activeTab={activeTab} onTabChange={handleTabChange} />
      
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        
        {activeTab === 'accounts' && !selectedAccountId && (
          <AccountsView
            accounts={filteredAccounts}
            searchTerm={searchTerm}
            onSearchChange={handleSearch}
            onAccountSelect={handleAccountSelect}
          />
        )}

        {activeTab === 'accounts' && selectedAccountId && (
          <AccountDetails
            accountId={selectedAccountId}
            onBack={handleBackToAccounts}
          />
        )}
        
        {activeTab !== 'accounts' && (
          <div className="flex-1 p-8">
            <div className="bg-white rounded-xl shadow-sm p-12 text-center h-full flex items-center justify-center">
              <div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">
                  {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Module
                </h3>
                <p className="text-gray-600 text-lg">
                  This module is coming soon. Switch to Accounts to see the full implementation.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;