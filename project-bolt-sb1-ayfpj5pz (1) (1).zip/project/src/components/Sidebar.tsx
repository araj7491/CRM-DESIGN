import React from 'react';
import { 
  LayoutDashboard,
  Users, 
  Building, 
  UserCheck, 
  Target, 
  FileText, 
  ShoppingCart,
  BarChart3,
  Calendar,
  Mail,
  Phone,
  Settings,
  HelpCircle,
  ChevronDown
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const Sidebar = ({ activeTab, onTabChange }: SidebarProps) => {
  const mainNavItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'leads', label: 'Leads', icon: Users, count: 24 },
    { id: 'accounts', label: 'Accounts', icon: Building, count: 156 },
    { id: 'contacts', label: 'Contacts', icon: UserCheck, count: 89 },
    { id: 'opportunities', label: 'Deals', icon: Target, count: 12 },
    { id: 'quotes', label: 'Quotes', icon: FileText },
    { id: 'orders', label: 'Orders', icon: ShoppingCart },
  ];

  const analyticsItems = [
    { id: 'reports', label: 'Reports', icon: BarChart3 },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  ];

  const toolsItems = [
    { id: 'calendar', label: 'Calendar', icon: Calendar },
    { id: 'email', label: 'Email', icon: Mail },
    { id: 'calls', label: 'Calls', icon: Phone },
  ];

  const NavItem = ({ item, isActive }: { item: any; isActive: boolean }) => {
    const Icon = item.icon;
    return (
      <button
        onClick={() => onTabChange(item.id)}
        className={`w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg transition-all duration-200 group ${
          isActive
            ? 'bg-blue-50 text-blue-700 shadow-sm'
            : 'text-gray-700 hover:text-gray-900 hover:bg-gray-50'
        }`}
      >
        <div className="flex items-center">
          <Icon className={`w-5 h-5 mr-3 ${isActive ? 'text-blue-600' : 'text-gray-500 group-hover:text-gray-700'}`} />
          {item.label}
        </div>
        {item.count && (
          <span className={`text-xs px-2 py-0.5 rounded-full ${
            isActive ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600'
          }`}>
            {item.count}
          </span>
        )}
      </button>
    );
  };

  const SectionHeader = ({ title, isCollapsible = false }: { title: string; isCollapsible?: boolean }) => (
    <div className="flex items-center justify-between px-3 py-2 mb-1">
      <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
        {title}
      </h3>
      {isCollapsible && (
        <ChevronDown className="w-4 h-4 text-gray-400" />
      )}
    </div>
  );

  return (
    <div className="w-64 bg-white border-r border-gray-200 h-screen flex flex-col">
      <div className="flex-1 px-4 py-6 overflow-y-auto">
        <nav className="space-y-1 mb-8">
          {mainNavItems.map((item) => (
            <NavItem key={item.id} item={item} isActive={activeTab === item.id} />
          ))}
        </nav>
        
        <div className="mb-6">
          <SectionHeader title="Analytics" />
          <nav className="space-y-1">
            {analyticsItems.map((item) => (
              <NavItem key={item.id} item={item} isActive={activeTab === item.id} />
            ))}
          </nav>
        </div>
        
        <div className="mb-6">
          <SectionHeader title="Tools" />
          <nav className="space-y-1">
            {toolsItems.map((item) => (
              <NavItem key={item.id} item={item} isActive={activeTab === item.id} />
            ))}
          </nav>
        </div>
      </div>
      
      <div className="border-t border-gray-200 p-4">
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 mb-4">
          <h4 className="text-sm font-semibold text-gray-900 mb-1">Upgrade to Pro</h4>
          <p className="text-xs text-gray-600 mb-3">Get advanced features and unlimited access</p>
          <button className="w-full bg-blue-600 text-white text-xs font-medium py-2 px-3 rounded-md hover:bg-blue-700 transition-colors duration-200">
            Upgrade Now
          </button>
        </div>
        
        <nav className="space-y-1">
          <NavItem item={{ id: 'settings', label: 'Settings', icon: Settings }} isActive={activeTab === 'settings'} />
          <NavItem item={{ id: 'help', label: 'Help & Support', icon: HelpCircle }} isActive={activeTab === 'help'} />
        </nav>
      </div>
    </div>
  );
};

export default Sidebar;