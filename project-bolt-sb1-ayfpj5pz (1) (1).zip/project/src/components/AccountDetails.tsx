import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Edit, 
  MoreHorizontal, 
  Phone, 
  Mail, 
  Globe, 
  MapPin, 
  Building, 
  Calendar, 
  DollarSign, 
  User, 
  FileText, 
  Target, 
  Activity, 
  Plus,
  ExternalLink,
  Star,
  Clock,
  TrendingUp,
  Users,
  Briefcase,
  ChevronDown,
  ChevronRight,
  Filter,
  Search,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Zap,
  BarChart3,
  PieChart,
  Calendar as CalendarIcon,
  MessageSquare,
  FileBarChart,
  Shield,
  Award,
  Bookmark,
  Link,
  Download,
  Upload,
  Eye,
  RefreshCw,
  Archive,
  Share2
} from 'lucide-react';

interface AccountDetailsProps {
  accountId: number;
  onBack: () => void;
}

const AccountDetails = ({ accountId, onBack }: AccountDetailsProps) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [showContactForm, setShowContactForm] = useState(false);
  const [showOpportunityForm, setShowOpportunityForm] = useState(false);

  // Enhanced mock data with business intelligence
  const account = {
    id: accountId,
    name: 'Acme Corporation',
    website: 'acme.com',
    industry: 'Manufacturing',
    type: 'Enterprise Customer',
    tier: 'Strategic',
    description: 'Leading manufacturer of industrial equipment and solutions with global operations across 15 countries',
    parentAccount: '',
    owner: 'Vishal Paswan',
    phone: '+1 (555) 123-4567',
    email: 'contact@acme.com',
    billingAddress: {
      street: '123 Industrial Blvd',
      city: 'Siliguri',
      state: 'West Bengal',
      postalCode: '734001',
      country: 'India'
    },
    shippingAddress: {
      street: '123 Industrial Blvd',
      city: 'Siliguri', 
      state: 'West Bengal',
      postalCode: '734001',
      country: 'India'
    },
    revenue: '$2.5M',
    employees: '250-500',
    founded: '1995',
    status: 'Active',
    rating: 4.5,
    lastActivity: '2 hours ago',
    nextActivity: 'Quarterly Business Review - Tomorrow 10:00 AM',
    healthScore: 85,
    riskLevel: 'Low',
    contractValue: '$2,500,000',
    contractExpiry: '2025-12-31',
    paymentTerms: 'Net 30',
    creditLimit: '$500,000',
    taxId: 'TAX123456789',
    sicCode: '3559',
    naicsCode: '333249',
    territory: 'North America - East',
    segment: 'Enterprise',
    source: 'Referral',
    tags: ['Strategic Account', 'High Value', 'Manufacturing']
  };

  const contacts = [
    {
      id: 1,
      name: 'John Smith',
      title: 'Chief Executive Officer',
      email: 'john.smith@acme.com',
      phone: '+1 (555) 123-4567',
      isPrimary: true,
      department: 'Executive',
      decisionMaker: true,
      lastContact: '2025-01-14'
    },
    {
      id: 2,
      name: 'Sarah Johnson',
      title: 'VP of Procurement',
      email: 'sarah.johnson@acme.com',
      phone: '+1 (555) 234-5678',
      isPrimary: false,
      department: 'Procurement',
      decisionMaker: true,
      lastContact: '2025-01-12'
    },
    {
      id: 3,
      name: 'Michael Chen',
      title: 'Finance Director',
      email: 'michael.chen@acme.com',
      phone: '+1 (555) 345-6789',
      isPrimary: false,
      department: 'Finance',
      decisionMaker: true,
      lastContact: '2025-01-10'
    }
  ];

  const opportunities = [
    {
      id: 1,
      name: 'Q1 2025 Equipment Upgrade',
      stage: 'Proposal Submitted',
      amount: '$150,000',
      closeDate: '2025-04-15',
      probability: 75,
      owner: 'Vishal Paswan',
      type: 'Upsell',
      source: 'Existing Business',
      competitorInfo: 'Competing with Siemens',
      lastActivity: 'Proposal presentation completed'
    },
    {
      id: 2,
      name: 'Annual Maintenance Contract Renewal',
      stage: 'Contract Negotiation',
      amount: '$85,000',
      closeDate: '2025-03-30',
      probability: 90,
      owner: 'Sarah Johnson',
      type: 'Renewal',
      source: 'Existing Business',
      competitorInfo: 'No competition',
      lastActivity: 'Terms discussion in progress'
    },
    {
      id: 3,
      name: 'Digital Transformation Initiative',
      stage: 'Discovery',
      amount: '$500,000',
      closeDate: '2025-08-15',
      probability: 35,
      owner: 'Vishal Paswan',
      type: 'New Business',
      source: 'Strategic Initiative',
      competitorInfo: 'Early stage evaluation',
      lastActivity: 'Requirements gathering session'
    }
  ];

  const activities = [
    {
      id: 1,
      type: 'meeting',
      title: 'Quarterly Business Review',
      date: '2025-01-15 10:30 AM',
      status: 'completed',
      notes: 'Reviewed Q4 performance, discussed Q1 objectives and budget allocation for new initiatives',
      attendees: ['John Smith', 'Sarah Johnson', 'Vishal Paswan'],
      outcome: 'Positive - Budget approved for Q1 upgrade'
    },
    {
      id: 2,
      type: 'email',
      title: 'Proposal Submission - Equipment Upgrade',
      date: '2025-01-14 2:15 PM',
      status: 'completed',
      notes: 'Comprehensive proposal submitted including technical specifications, implementation timeline, and ROI analysis',
      outcome: 'Awaiting stakeholder review'
    },
    {
      id: 3,
      type: 'call',
      title: 'Contract Renewal Discussion',
      date: '2025-01-16 3:00 PM',
      status: 'scheduled',
      notes: 'Discuss renewal terms, pricing adjustments, and service level agreements',
      attendees: ['Sarah Johnson', 'Michael Chen']
    },
    {
      id: 4,
      type: 'meeting',
      title: 'Technical Requirements Workshop',
      date: '2025-01-13 2:00 PM',
      status: 'completed',
      notes: 'Deep dive into technical specifications for the digital transformation project',
      attendees: ['Technical Team', 'Vishal Paswan'],
      outcome: 'Requirements documented and approved'
    },
    {
      id: 5,
      type: 'call',
      title: 'Follow-up on Proposal Feedback',
      date: '2025-01-18 11:00 AM',
      status: 'scheduled',
      notes: 'Review feedback from stakeholders and address any concerns',
      attendees: ['John Smith', 'Vishal Paswan']
    }
  ];

  const documents = [
    {
      id: 1,
      name: 'Master Service Agreement',
      type: 'Contract',
      size: '2.4 MB',
      uploadDate: '2024-12-15',
      category: 'Legal',
      status: 'Active'
    },
    {
      id: 2,
      name: 'Q1 2025 Proposal',
      type: 'Proposal',
      size: '5.8 MB',
      uploadDate: '2025-01-14',
      category: 'Sales',
      status: 'Under Review'
    },
    {
      id: 3,
      name: 'Technical Specifications',
      type: 'Technical',
      size: '1.2 MB',
      uploadDate: '2025-01-13',
      category: 'Technical',
      status: 'Approved'
    },
    {
      id: 4,
      name: 'Financial Statement 2024',
      type: 'Financial',
      size: '890 KB',
      uploadDate: '2024-12-31',
      category: 'Finance',
      status: 'Confidential'
    }
  ];

  const businessMetrics = {
    totalRevenue: '$2,500,000',
    avgDealSize: '$125,000',
    salesCycle: '45 days',
    winRate: '78%',
    customerLifetime: '5.2 years',
    churnRisk: 'Low',
    nps: 8.5,
    csat: '92%'
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Activity },
    { id: 'contacts', label: 'Contacts', icon: Users, count: contacts.length },
    { id: 'opportunities', label: 'Opportunities', icon: Target, count: opportunities.length },
    { id: 'activities', label: 'Activities', icon: Clock, count: activities.length },
    { id: 'documents', label: 'Documents', icon: FileText, count: documents.length },
    { id: 'financials', label: 'Financials', icon: DollarSign },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 }
  ];

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getStageColor = (stage: string) => {
    const colors = {
      'Discovery': 'bg-blue-100 text-blue-800 border-blue-200',
      'Proposal Submitted': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'Contract Negotiation': 'bg-orange-100 text-orange-800 border-orange-200',
      'Closed Won': 'bg-green-100 text-green-800 border-green-200',
      'Closed Lost': 'bg-red-100 text-red-800 border-red-200'
    };
    return colors[stage as keyof typeof colors] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const getActivityIcon = (type: string) => {
    const icons = {
      'call': Phone,
      'email': Mail,
      'meeting': Users,
      'task': FileText,
      'note': MessageSquare
    };
    return icons[type as keyof typeof icons] || Activity;
  };

  const getHealthScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getRiskLevelColor = (risk: string) => {
    const colors = {
      'Low': 'bg-green-100 text-green-800 border-green-200',
      'Medium': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'High': 'bg-red-100 text-red-800 border-red-200'
    };
    return colors[risk as keyof typeof colors] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const getDocumentIcon = (type: string) => {
    const icons = {
      'Contract': Shield,
      'Proposal': FileText,
      'Technical': FileBarChart,
      'Financial': DollarSign
    };
    return icons[type as keyof typeof icons] || FileText;
  };

  const getDocumentStatusColor = (status: string) => {
    const colors = {
      'Active': 'bg-green-100 text-green-800',
      'Under Review': 'bg-yellow-100 text-yellow-800',
      'Approved': 'bg-blue-100 text-blue-800',
      'Confidential': 'bg-red-100 text-red-800'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="flex-1 flex flex-col bg-gray-50 min-h-screen">
      {/* Enhanced Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button 
              onClick={onBack}
              className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors duration-200"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            
            <div className="flex items-center space-x-4">
              <div className="h-14 w-14 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white text-xl font-bold">
                  {getInitials(account.name)}
                </span>
              </div>
              
              <div>
                <div className="flex items-center space-x-3">
                  <h1 className="text-2xl font-bold text-gray-900">{account.name}</h1>
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getRiskLevelColor(account.riskLevel)}`}>
                    {account.riskLevel} Risk
                  </span>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800 border border-blue-200">
                    {account.tier}
                  </span>
                </div>
                <div className="flex items-center space-x-6 mt-2">
                  <div className="flex items-center space-x-2">
                    <Globe className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">{account.website}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Building className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">{account.industry}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-gray-400" />
                    <span className="text-gray-600">{account.employees} employees</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <span className="text-sm text-gray-500">Health Score:</span>
                    <span className={`text-sm font-bold ${getHealthScoreColor(account.healthScore)}`}>
                      {account.healthScore}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <button className="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-200">
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </button>
            <button className="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-200">
              <Download className="w-4 h-4 mr-2" />
              Export
            </button>
            <button className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 transition-colors duration-200">
              <Edit className="w-4 h-4 mr-2" />
              Edit Account
            </button>
            <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors duration-200">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Business Intelligence Dashboard */}
      <div className="bg-white border-b border-gray-200 px-6 py-6">
        <div className="grid grid-cols-8 gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">{account.contractValue}</div>
            <div className="text-sm text-gray-600">Contract Value</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">{businessMetrics.totalRevenue}</div>
            <div className="text-sm text-gray-600">Total Revenue</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">{opportunities.length}</div>
            <div className="text-sm text-gray-600">Active Opportunities</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">{contacts.length}</div>
            <div className="text-sm text-gray-600">Key Contacts</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">{businessMetrics.winRate}</div>
            <div className="text-sm text-gray-600">Win Rate</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">{businessMetrics.salesCycle}</div>
            <div className="text-sm text-gray-600">Avg Sales Cycle</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">{businessMetrics.nps}</div>
            <div className="text-sm text-gray-600">NPS Score</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">{businessMetrics.csat}</div>
            <div className="text-sm text-gray-600">CSAT</div>
          </div>
        </div>
      </div>

      {/* Enhanced Tabs */}
      <div className="bg-white border-b border-gray-200 px-6">
        <nav className="flex space-x-8">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200 ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Icon className="w-4 h-4 mr-2" />
                {tab.label}
                {tab.count && (
                  <span className="ml-2 bg-gray-100 text-gray-600 py-0.5 px-2 rounded-full text-xs font-semibold">
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Content */}
      <div className="flex-1 p-6">
        {activeTab === 'overview' && (
          <div className="grid grid-cols-4 gap-6">
            {/* Left Column - Account Information */}
            <div className="col-span-2 space-y-6">
              {/* Company Profile */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-gray-900">Company Profile</h3>
                  <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
                    Edit
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Legal Name</label>
                      <div className="text-sm text-gray-900 font-medium">{account.name}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Industry</label>
                      <div className="text-sm text-gray-900">{account.industry}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Account Type</label>
                      <div className="text-sm text-gray-900">{account.type}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Founded</label>
                      <div className="text-sm text-gray-900">{account.founded}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">SIC Code</label>
                      <div className="text-sm text-gray-900">{account.sicCode}</div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Website</label>
                      <div className="flex items-center space-x-2">
                        <Globe className="w-4 h-4 text-gray-400" />
                        <a href={`https://${account.website}`} className="text-sm text-blue-600 hover:text-blue-800">
                          {account.website}
                        </a>
                        <ExternalLink className="w-3 h-3 text-gray-400" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Employees</label>
                      <div className="text-sm text-gray-900">{account.employees}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Territory</label>
                      <div className="text-sm text-gray-900">{account.territory}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Segment</label>
                      <div className="text-sm text-gray-900">{account.segment}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">NAICS Code</label>
                      <div className="text-sm text-gray-900">{account.naicsCode}</div>
                    </div>
                  </div>
                </div>
                {account.description && (
                  <div className="mt-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                    <p className="text-sm text-gray-600 leading-relaxed">{account.description}</p>
                  </div>
                )}
                <div className="mt-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Tags</label>
                  <div className="flex flex-wrap gap-2">
                    {account.tags.map((tag, index) => (
                      <span key={index} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Financial Information */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-6">Financial Information</h3>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Annual Revenue</label>
                      <div className="text-sm text-gray-900 font-semibold">{account.revenue}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Contract Value</label>
                      <div className="text-sm text-gray-900 font-semibold">{account.contractValue}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Credit Limit</label>
                      <div className="text-sm text-gray-900">{account.creditLimit}</div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Payment Terms</label>
                      <div className="text-sm text-gray-900">{account.paymentTerms}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Contract Expiry</label>
                      <div className="text-sm text-gray-900">{account.contractExpiry}</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Tax ID</label>
                      <div className="text-sm text-gray-900">{account.taxId}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact Information */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-6">Contact Information</h3>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Primary Phone</label>
                    <div className="flex items-center space-x-2">
                      <Phone className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-900">{account.phone}</span>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Primary Email</label>
                    <div className="flex items-center space-x-2">
                      <Mail className="w-4 h-4 text-gray-400" />
                      <a href={`mailto:${account.email}`} className="text-sm text-blue-600 hover:text-blue-800">
                        {account.email}
                      </a>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-6 mt-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Billing Address</label>
                    <div className="flex items-start space-x-2">
                      <MapPin className="w-4 h-4 text-gray-400 mt-0.5" />
                      <div className="text-sm text-gray-900">
                        <div>{account.billingAddress.street}</div>
                        <div>{account.billingAddress.city}, {account.billingAddress.state}</div>
                        <div>{account.billingAddress.postalCode}</div>
                        <div>{account.billingAddress.country}</div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Shipping Address</label>
                    <div className="flex items-start space-x-2">
                      <MapPin className="w-4 h-4 text-gray-400 mt-0.5" />
                      <div className="text-sm text-gray-900">
                        <div>{account.shippingAddress.street}</div>
                        <div>{account.shippingAddress.city}, {account.shippingAddress.state}</div>
                        <div>{account.shippingAddress.postalCode}</div>
                        <div>{account.shippingAddress.country}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Middle Column - Opportunities & Activities */}
            <div className="space-y-6">
              {/* Pipeline Overview */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Pipeline Overview</h3>
                  <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
                    View All
                  </button>
                </div>
                <div className="space-y-4">
                  {opportunities.slice(0, 2).map((opportunity) => (
                    <div key={opportunity.id} className="p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-semibold text-gray-900">{opportunity.name}</h4>
                        <span className="text-sm font-semibold text-gray-900">{opportunity.amount}</span>
                      </div>
                      <div className="flex items-center justify-between mb-3">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${getStageColor(opportunity.stage)}`}>
                          {opportunity.stage}
                        </span>
                        <span className="text-xs text-gray-500">{opportunity.closeDate}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                          style={{ width: `${opportunity.probability}%` }}
                        ></div>
                      </div>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-gray-500">{opportunity.probability}% probability</span>
                        <span className="text-xs text-gray-500">{opportunity.type}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent Activities */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Recent Activities</h3>
                  <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
                    View All
                  </button>
                </div>
                <div className="space-y-4">
                  {activities.slice(0, 3).map((activity) => {
                    const Icon = getActivityIcon(activity.type);
                    return (
                      <div key={activity.id} className="flex items-start space-x-3">
                        <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                          activity.status === 'completed' ? 'bg-green-100' : 'bg-blue-100'
                        }`}>
                          <Icon className={`w-4 h-4 ${
                            activity.status === 'completed' ? 'text-green-600' : 'text-blue-600'
                          }`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-gray-900">{activity.title}</div>
                          <div className="text-xs text-gray-600">{activity.date}</div>
                          {activity.notes && (
                            <div className="text-xs text-gray-500 mt-1 line-clamp-2">{activity.notes}</div>
                          )}
                          {activity.outcome && (
                            <div className="text-xs text-green-600 mt-1 font-medium">{activity.outcome}</div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Right Column - Key Contacts & Insights */}
            <div className="space-y-6">
              {/* Account Health */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Account Health</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Health Score</span>
                    <span className={`text-sm font-bold ${getHealthScoreColor(account.healthScore)}`}>
                      {account.healthScore}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-300 ${
                        account.healthScore >= 80 ? 'bg-green-500' : 
                        account.healthScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                      style={{ width: `${account.healthScore}%` }}
                    ></div>
                  </div>
                  <div className="space-y-3 mt-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Risk Level</span>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${getRiskLevelColor(account.riskLevel)}`}>
                        {account.riskLevel}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Customer Lifetime</span>
                      <span className="text-sm font-semibold text-gray-900">{businessMetrics.customerLifetime}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Churn Risk</span>
                      <span className="text-sm font-semibold text-green-600">{businessMetrics.churnRisk}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Key Contacts */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">Key Contacts</h3>
                  <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
                    View All
                  </button>
                </div>
                <div className="space-y-4">
                  {contacts.slice(0, 3).map((contact) => (
                    <div key={contact.id} className="flex items-center space-x-3">
                      <div className="h-10 w-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                        <span className="text-white text-sm font-semibold">
                          {getInitials(contact.name)}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-semibold text-gray-900">{contact.name}</span>
                          {contact.isPrimary && (
                            <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              Primary
                            </span>
                          )}
                          {contact.decisionMaker && (
                            <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              Decision Maker
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-gray-600">{contact.title}</div>
                        <div className="text-xs text-gray-500">{contact.department}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Next Actions */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Next Actions</h3>
                <div className="bg-blue-50 rounded-lg p-4 mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="h-8 w-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <CalendarIcon className="w-4 h-4 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm font-medium text-gray-900">Quarterly Business Review</div>
                      <div className="text-xs text-gray-600">Tomorrow at 10:00 AM</div>
                    </div>
                  </div>
                </div>
                <div className="space-y-3">
                  <button className="w-full text-left p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-150">
                    <div className="text-sm font-medium text-gray-900">Schedule contract renewal discussion</div>
                    <div className="text-xs text-gray-500">Due in 2 days</div>
                  </button>
                  <button className="w-full text-left p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-150">
                    <div className="text-sm font-medium text-gray-900">Follow up on proposal feedback</div>
                    <div className="text-xs text-gray-500">Due in 5 days</div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'contacts' && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Contacts ({contacts.length})</h3>
                <div className="flex items-center space-x-3">
                  <button className="inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                    <Filter className="w-4 h-4 mr-2" />
                    Filter
                  </button>
                  <button className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 transition-colors duration-200">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Contact
                  </button>
                </div>
              </div>
            </div>
            <div className="p-6">
              <div className="grid gap-4">
                {contacts.map((contact) => (
                  <div key={contact.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-150">
                    <div className="flex items-center space-x-4">
                      <div className="h-12 w-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                        <span className="text-white text-sm font-semibold">
                          {getInitials(contact.name)}
                        </span>
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-semibold text-gray-900">{contact.name}</span>
                          {contact.isPrimary && (
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              Primary
                            </span>
                          )}
                          {contact.decisionMaker && (
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              Decision Maker
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-gray-600">{contact.title}</div>
                        <div className="flex items-center space-x-4 mt-1">
                          <span className="text-xs text-gray-500">{contact.email}</span>
                          <span className="text-xs text-gray-500">{contact.phone}</span>
                          <span className="text-xs text-gray-500">Last contact: {contact.lastContact}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors duration-150 rounded">
                        <Phone className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors duration-150 rounded">
                        <Mail className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors duration-150 rounded">
                        <MoreHorizontal className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'opportunities' && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Opportunities ({opportunities.length})</h3>
                <div className="flex items-center space-x-3">
                  <button className="inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                    <Filter className="w-4 h-4 mr-2" />
                    Filter
                  </button>
                  <button className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 transition-colors duration-200">
                    <Plus className="w-4 h-4 mr-2" />
                    New Opportunity
                  </button>
                </div>
              </div>
            </div>
            <div className="p-6">
              <div className="grid gap-6">
                {opportunities.map((opportunity) => (
                  <div key={opportunity.id} className="p-6 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-150">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <h4 className="text-lg font-semibold text-gray-900">{opportunity.name}</h4>
                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getStageColor(opportunity.stage)}`}>
                          {opportunity.stage}
                        </span>
                      </div>
                      <div className="text-xl font-bold text-gray-900">{opportunity.amount}</div>
                    </div>
                    
                    <div className="grid grid-cols-4 gap-6 mb-4">
                      <div>
                        <span className="text-sm text-gray-500">Close Date:</span>
                        <div className="font-medium text-gray-900">{opportunity.closeDate}</div>
                      </div>
                      <div>
                        <span className="text-sm text-gray-500">Probability:</span>
                        <div className="font-medium text-gray-900">{opportunity.probability}%</div>
                      </div>
                      <div>
                        <span className="text-sm text-gray-500">Owner:</span>
                        <div className="font-medium text-gray-900">{opportunity.owner}</div>
                      </div>
                      <div>
                        <span className="text-sm text-gray-500">Type:</span>
                        <div className="font-medium text-gray-900">{opportunity.type}</div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-500">Progress</span>
                        <span className="text-sm font-medium text-gray-900">{opportunity.probability}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div 
                          className="bg-blue-600 h-3 rounded-full transition-all duration-300" 
                          style={{ width: `${opportunity.probability}%` }}
                        ></div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-6 text-sm">
                      <div>
                        <span className="text-gray-500">Source:</span>
                        <div className="font-medium text-gray-900">{opportunity.source}</div>
                      </div>
                      <div>
                        <span className="text-gray-500">Competition:</span>
                        <div className="font-medium text-gray-900">{opportunity.competitorInfo}</div>
                      </div>
                    </div>

                    {opportunity.lastActivity && (
                      <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                        <div className="text-sm font-medium text-blue-900">Last Activity</div>
                        <div className="text-sm text-blue-700">{opportunity.lastActivity}</div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'activities' && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Activities ({activities.length})</h3>
                <div className="flex items-center space-x-3">
                  <button className="inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                    <Filter className="w-4 h-4 mr-2" />
                    Filter
                  </button>
                  <button className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 transition-colors duration-200">
                    <Plus className="w-4 h-4 mr-2" />
                    Log Activity
                  </button>
                </div>
              </div>
            </div>
            <div className="p-6">
              <div className="space-y-6">
                {activities.map((activity) => {
                  const Icon = getActivityIcon(activity.type);
                  return (
                    <div key={activity.id} className="flex items-start space-x-4 p-6 border border-gray-200 rounded-lg">
                      <div className={`h-12 w-12 rounded-full flex items-center justify-center ${
                        activity.status === 'completed' ? 'bg-green-100' : 'bg-blue-100'
                      }`}>
                        <Icon className={`w-6 h-6 ${
                          activity.status === 'completed' ? 'text-green-600' : 'text-blue-600'
                        }`} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-lg font-semibold text-gray-900">{activity.title}</h4>
                          <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                            activity.status === 'completed' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-blue-100 text-blue-800'
                          }`}>
                            {activity.status}
                          </span>
                        </div>
                        <div className="text-sm text-gray-600 mb-3">{activity.date}</div>
                        {activity.notes && (
                          <div className="text-sm text-gray-700 mb-3 leading-relaxed">{activity.notes}</div>
                        )}
                        {activity.attendees && (
                          <div className="mb-3">
                            <span className="text-sm font-medium text-gray-700">Attendees: </span>
                            <span className="text-sm text-gray-600">{activity.attendees.join(', ')}</span>
                          </div>
                        )}
                        {activity.outcome && (
                          <div className="p-3 bg-green-50 rounded-lg">
                            <div className="text-sm font-medium text-green-900">Outcome</div>
                            <div className="text-sm text-green-700">{activity.outcome}</div>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'documents' && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Documents ({documents.length})</h3>
                <div className="flex items-center space-x-3">
                  <button className="inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                    <Filter className="w-4 h-4 mr-2" />
                    Filter
                  </button>
                  <button className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 transition-colors duration-200">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Document
                  </button>
                </div>
              </div>
            </div>
            <div className="p-6">
              <div className="grid gap-4">
                {documents.map((document) => {
                  const Icon = getDocumentIcon(document.type);
                  return (
                    <div key={document.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-150">
                      <div className="flex items-center space-x-4">
                        <div className="h-12 w-12 bg-gray-100 rounded-lg flex items-center justify-center">
                          <Icon className="w-6 h-6 text-gray-600" />
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="text-sm font-semibold text-gray-900">{document.name}</span>
                            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getDocumentStatusColor(document.status)}`}>
                              {document.status}
                            </span>
                          </div>
                          <div className="text-sm text-gray-600">{document.type} • {document.category}</div>
                          <div className="flex items-center space-x-4 mt-1">
                            <span className="text-xs text-gray-500">{document.size}</span>
                            <span className="text-xs text-gray-500">Uploaded: {document.uploadDate}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors duration-150 rounded">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors duration-150 rounded">
                          <Download className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-gray-400 hover:text-gray-600 transition-colors duration-150 rounded">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'financials' && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Financial Overview</h3>
                <button className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 transition-colors duration-200">
                  <FileBarChart className="w-4 h-4 mr-2" />
                  Generate Report
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-3 gap-6 mb-8">
                <div className="bg-gradient-to-r from-green-50 to-green-100 p-6 rounded-xl">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-bold text-green-900">{account.contractValue}</div>
                      <div className="text-sm text-green-700">Total Contract Value</div>
                    </div>
                    <DollarSign className="w-8 h-8 text-green-600" />
                  </div>
                </div>
                <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-6 rounded-xl">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-bold text-blue-900">{account.revenue}</div>
                      <div className="text-sm text-blue-700">Annual Revenue</div>
                    </div>
                    <TrendingUp className="w-8 h-8 text-blue-600" />
                  </div>
                </div>
                <div className="bg-gradient-to-r from-purple-50 to-purple-100 p-6 rounded-xl">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-bold text-purple-900">{businessMetrics.avgDealSize}</div>
                      <div className="text-sm text-purple-700">Average Deal Size</div>
                    </div>
                    <Target className="w-8 h-8 text-purple-600" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="p-6 border border-gray-200 rounded-lg">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Payment Information</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Payment Terms</span>
                      <span className="font-medium">{account.paymentTerms}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Credit Limit</span>
                      <span className="font-medium">{account.creditLimit}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Contract Expiry</span>
                      <span className="font-medium">{account.contractExpiry}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Tax ID</span>
                      <span className="font-medium">{account.taxId}</span>
                    </div>
                  </div>
                </div>

                <div className="p-6 border border-gray-200 rounded-lg">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Performance Metrics</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Win Rate</span>
                      <span className="font-medium text-green-600">{businessMetrics.winRate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Sales Cycle</span>
                      <span className="font-medium">{businessMetrics.salesCycle}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Customer Lifetime</span>
                      <span className="font-medium">{businessMetrics.customerLifetime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Churn Risk</span>
                      <span className="font-medium text-green-600">{businessMetrics.churnRisk}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Business Analytics</h3>
                <button className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 transition-colors duration-200">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Create Dashboard
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-2 gap-6 mb-8">
                <div className="p-6 border border-gray-200 rounded-lg">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Customer Satisfaction</h4>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">NPS Score</span>
                      <span className="text-2xl font-bold text-green-600">{businessMetrics.nps}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">CSAT</span>
                      <span className="text-2xl font-bold text-green-600">{businessMetrics.csat}</span>
                    </div>
                  </div>
                </div>

                <div className="p-6 border border-gray-200 rounded-lg">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Account Health</h4>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Health Score</span>
                      <span className={`text-2xl font-bold ${getHealthScoreColor(account.healthScore)}`}>
                        {account.healthScore}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div 
                        className={`h-3 rounded-full transition-all duration-300 ${
                          account.healthScore >= 80 ? 'bg-green-500' : 
                          account.healthScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${account.healthScore}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 border border-gray-200 rounded-lg">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Pipeline Analysis</h4>
                <div className="grid grid-cols-4 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{opportunities.length}</div>
                    <div className="text-sm text-gray-600">Total Opportunities</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      ${opportunities.reduce((sum, opp) => sum + parseInt(opp.amount.replace(/[$,]/g, '')), 0).toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-600">Pipeline Value</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {Math.round(opportunities.reduce((sum, opp) => sum + opp.probability, 0) / opportunities.length)}%
                    </div>
                    <div className="text-sm text-gray-600">Avg Probability</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">
                      {opportunities.filter(opp => opp.stage === 'Contract Negotiation').length}
                    </div>
                    <div className="text-sm text-gray-600">In Negotiation</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AccountDetails;